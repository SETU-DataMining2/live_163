df1 = df.groupby(['Student','Module'])[ ['W_Mark'] ].sum()
def tmp(row):
    style = 'background-color: %s' % group_color["".join(row.name)]
    return [style] * (len(row))
df1.style.apply(tmp, axis=1)