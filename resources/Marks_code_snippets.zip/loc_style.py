def style_query_1(row):
    style = 'background-color: %s' % ('lightgreen' if row.Module=='Maths' else 'white')
    styles = [''] * len(row)
    styles[0] = styles[4] = style
    return styles
df.style.apply(style_query_1, axis=1)