#!/usr/bin/env python

# source: sklearn

from sklearn.decomposition import PCA
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis

import pandas as pd

# load dataset
df_all = pd.read_csv("data/churn.csv")

# fix col names
names = df_all.columns.tolist()
CORRECTIONS = {" ":"_", "'":"", "?":"", "CustServ":"Cust_Serv"}
def fixName(s):
    for a,b in CORRECTIONS.items():
        s = s.replace(a,b)
    return s
mapping = {c:fixName(c) for c in names}
df_all.rename(columns=mapping, inplace=True)

# fix categatorical varaibles
df_all.Intl_Plan = df_all.Intl_Plan.map( {"yes":1, "no":0} )
df_all.VMail_Plan = df_all.VMail_Plan.apply( lambda x: int(x=='yes') )
df_all.Churn = df_all.Churn.apply( lambda x: int(x=="True.") )

# train-test split
target = "Churn"
attributes = df_all.columns.tolist()
attributes.remove(target)
attributes = [a for a in attributes if a not in ["State", "Phone", "Area_Code"]]
from sklearn.model_selection import train_test_split
df_model = df_all.loc[:, attributes + [target]]
df_train, df_test = train_test_split(df_model, stratify=df_model[target], test_size=.25, random_state=42)

from sklearn.preprocessing import StandardScaler

# scale data
scaler = StandardScaler()
X_train = scaler.fit_transform(df_model.loc[:,attributes].astype(float))
y_train = df_train.Churn.values
X_test = scaler.transform(df_test.loc[:,attributes].astype(float))
y_test = df_test.Churn.values

# pca
from sklearn.decomposition import PCA
pca = PCA(n_components=len(attributes))
X_pca = pca.fit(X_train).transform(X_train)
print('Explained variance ratio:\n%s'
      % ["%.4g" % v for v in pca.explained_variance_ratio_])
