#!/usr/bin/env python

import sys, re
P = r"\color{blue}{}"
M = r"\color{red}{}"
    
def markup_match(regex, text, name):
    """Utility function to generate LaTeX result of matching regexs.

    Output saved to to folder 'output' as multiple files using 'name' as base
    """

    #print ("REGRX: %s \t TEXT: %s" % (regex, text))
    filename = lambda variant: "output/%s_%s.tex" % (name, variant)

    open(filename("re"),"wt").write(r"\verb!/%s/!" % regex)
    open(filename("text"),"wt").write(text)

    ms = list(re.finditer(regex,text))

    out = text
    for m in reversed(ms):
        out = out[:m.start()] + M + out[m.start():m.end()] + P + out[m.end():]

    open(filename("out"),"wt").write(P+out)

    return ms

if __name__=="__main__":

    if len(sys.argv)==4:
        regex, text, name = sys.argv[1:4]
        markup_match(regex, text, name)
    else:

        # literal characters
        text = "A Jack and Phil went up a hill."
        markup_match(r"a", text, "literal_1")
        markup_match(r"hil", text, "literal_2")
        markup_match(r"upthe", text, "literal_3")
        markup_match(r"il.", text, "literal_4")
        
        # wildcard metacharacter
        markup_match(r"h.t", "The hot MAGA hat sat on the heated hob.", "wildcard_1")
        markup_match(r"9.00", "9.00 vs 9500 vs 9:00", "wildcard_2")

        # excape metacharacter
        markup_match(r"9\.00", "9.00 vs 9500 vs 9:00", "escape_1")

        # character set 
        markup_match(r"[aeiou]", "My queue is not a stack", "set_1")
        markup_match(r"gr[ae]y", "Is the colour gray or grey?", "set_2")
        markup_match(r"[01234567890]", "8 out of 10 cats does countdown", "set_3")

        # sequence of RE to correctly identify the 
        text = "The thesis title is 'The tithe of the Theron.'"
        markup_match(r"the", text, "the_1")
        markup_match(r"[Tt]he", text, "the_2")
        markup_match(r"\b[tT]he\b", text, "the_3")

        # negative character sets
        markup_match(r"[^aeiou]", "My queue is not a stack", "negative_1")
        markup_match(r"[a^eiou]", "My queue is not a stack", "negative_2")
        markup_match(r"[Ss]ee[^mn]", "The Seeker does see but does not seem to have seen.", "negative_3")
        
        # metacharacters inside character sets
        markup_match(r"h[abc.xyz]t", "My hat is not hot but is h.t", "meta_inside_1")
        markup_match(r"[\[\]]", "[] brackets rule! Down with parentheses!", "meta_inside_2")
        
        # shorthard
        markup_match(r"\s\d\d\d\d\s", "Reading 1984 in 1984 was cool only in 1984.", "shorthand_1")
        markup_match(r"\s\w\w\w\w\s", "Reading 1984 in 1984 was cool only in 1984.", "shorthand_2")
        
        # repetition
        markup_match(r"apples*", "apple, apples, applesss, applesss5s", "repetition_1")
        markup_match(r"apples+", "apple, apples, applesss, applesss5s", "repetition_2")
        markup_match(r"apples?", "apple, apples, applesss, applesss5s", "repetition_3")
        markup_match(r"\d\d\d\d*", "1, 12, 123, 1234, 12345, 123456", "repetition_4")

        # quantified 
        markup_match(r"A{1,2}", "A bonds, AA bonds, AAA bonds", "quantified_1")
               
        # greedy vs no -greedy
        text = "<a href='http://www.sjsu.edu'>Welcome to SJSU</a>"
        markup_match(r"<.+>", text, "greedy_1")
        markup_match(r"<.+?>", text, "greedy_2")
        