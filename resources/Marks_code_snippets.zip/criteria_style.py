def style_query_1(row):
    criteria = ((row.Mark<50) & (row.Module=='Maths')) | ((row.Mark<70) & (row.Module!='Maths'))
    style = 'background-color: %s' % ('lightgreen' if criteria else 'white')
    styles = [''] * len(row)
    styles[0] = styles[1] = styles[4] = style
    return styles
df.style.apply(style_query_1, axis=1)