df["Weight"] = df["Weight"].astype('int')
df["Weight"].dtype