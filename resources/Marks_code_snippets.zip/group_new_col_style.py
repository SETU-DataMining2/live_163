def tmp(row):
    k = row.Student + row.Module
    
    style = 'background-color: %s' %  group_color[k]
    return [style] * (len(row)-1) + ['background-color: %s' % 'lightgreen' ]

df.style.apply(tmp, axis=1)