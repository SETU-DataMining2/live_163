#!/usr/bin/env python3

import pandas as pd
pd.set_option("display.width",120)

# Input data

filename = "data/auto-mpg/auto-mpg.data"
print ("Loading data (%s) ...\n" % filename)

column_names = ['mpg', 'cylinders', 'displacement', 'horsepower', 'weight', 'acceleration', 'year', 'origin', 'name']
df = pd.read_csv(filename, delim_whitespace=True, names=column_names)
print("Inputted dataset has %s observations (rows) with %s variables (columns)\n" %  df.shape)

# First lokk at data 

print("First 5 rows ...\n", df.head(5))

print("\nData types of variables  ...\n", df.dtypes)

# Cleaning the data 
# 1. Feature horsepower has (6) missing values and should be of type float or int
#    Soln: change type to float and use mean for nan 
#    a/ First assign NaN to the missing data locations,
#    b/ change the data type of the 'horsepower' column to 'float'
#    c/ assign each missing location the mean value of the column

horsepower_missing_ind = df[df.horsepower=='?'].index
print ("There are %s missing values in column 'horsepower' ... " % len(horsepower_missing_ind))
print(df.loc[horsepower_missing_ind])

df.loc[horsepower_missing_ind, 'horsepower'] = float('nan')
df.horsepower = df.horsepower.apply(pd.to_numeric)
df.loc[horsepower_missing_ind, 'horsepower'] = int( df.horsepower.mean() )

print("\nSummary of dataset ...")
print(df.describe())


df.to_csv("auto-mpg_clean.csv", index=False)
