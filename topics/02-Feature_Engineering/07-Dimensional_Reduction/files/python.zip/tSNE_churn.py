#!/usr/bin/env python

# source: sklearn

import matplotlib.pyplot as plt
import seaborn as sns
sns.set()
sns.set(style="whitegrid")
sns.set_context("notebook")

from sklearn.decomposition import PCA
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis

import pandas as pd

# load dataset
df_all = pd.read_csv("data/churn.csv")

# fix col names
names = df_all.columns.tolist()
CORRECTIONS = {" ":"_", "'":"", "?":"", "CustServ":"Cust_Serv"}
def fixName(s):
    for a,b in CORRECTIONS.items():
        s = s.replace(a,b)
    return s
mapping = {c:fixName(c) for c in names}
df_all.rename(columns=mapping, inplace=True)

# fix categatorical varaibles
df_all.Intl_Plan = df_all.Intl_Plan.map( {"yes":1, "no":0} )
df_all.VMail_Plan = df_all.VMail_Plan.apply( lambda x: int(x=='yes') )
df_all.Churn = df_all.Churn.apply( lambda x: int(x=="True.") )

# train-test split
target = "Churn"
attributes = df_all.columns.tolist()
attributes.remove(target)
attributes = [a for a in attributes if a not in ["State", "Phone", "Area_Code"]]
from sklearn.model_selection import train_test_split
df_model = df_all.loc[:, attributes + [target]]
df_train, df_test = train_test_split(df_model, stratify=df_model[target], test_size=.25, random_state=42)

from sklearn.preprocessing import StandardScaler

# scale data
scaler = StandardScaler()
X_train = scaler.fit_transform(df_model.loc[:,attributes].astype(float))
y_train = df_train.Churn.values
X_test = scaler.transform(df_test.loc[:,attributes].astype(float))
y_test = df_test.Churn.values

# t-SNE
import time

t0 = time.time()
from sklearn.manifold import TSNE
tsne = TSNE(random_state=142)
tsne_repr = tsne.fit_transform(X_train)
t1 = time.time()
print ("TSME took %f seconds" % (t1-t0))

plt.scatter(tsne_repr[:, 0], tsne_repr[:, 1], alpha=.5, s=10);
plt.savefig("tSNE_churn_1.png", bbox_inches="tight")

plt.scatter(tsne_repr[:, 0], tsne_repr[:, 1],
    c=df_model['Churn'].map({False: 'blue', True: 'orange'}), alpha=.5, s=10);
plt.savefig("tSNE_churn_2.png", bbox_inches="tight")

fig, axes = plt.subplots(1, 2, sharey=True, figsize=(12, 5))

for i, name in enumerate(['Intl_Plan', 'VMail_Plan']):
    axes[i].scatter(tsne_repr[:, 0], tsne_repr[:, 1],
    c=df_model[name].map({False: 'blue', True: 'orange'}), alpha=.5, s=10);
    axes[i].set_title(name);
plt.savefig("tSNE_churn_3.png", bbox_inches="tight")
