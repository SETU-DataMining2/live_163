#!/usr/bin/env python3

import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns 
sns.set()
DPI = 100

from sklearn.pipeline import Pipeline
from sklearn.preprocessing import PolynomialFeatures
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import cross_val_score
from sklearn.metrics import mean_squared_error, r2_score

def true_fun(X):
    return np.cos(1.5 * np.pi * X)
    
def generate_fit(degree, show_true=False, show_fig=False, save_fig=False):
    polynomial_features = PolynomialFeatures(degree=degree, include_bias=False)
    linear_regression = LinearRegression()
    pipeline = Pipeline([("polynomial_features", polynomial_features),
                         ("linear_regression", linear_regression)])
    pipeline.fit(X[:, np.newaxis], y)
    
    # Evaluate the models using crossvalidation
    scores = cross_val_score(pipeline, X[:, np.newaxis], y,
        scoring="neg_mean_squared_error", cv=10)
        
    X_test = np.linspace(0, 1, 100)
        
    plt.clf()
    plt.plot(X_test, pipeline.predict(X_test[:, np.newaxis]), 'g', label="Model")
    if show_true: plt.plot(X_test, true_fun(X_test), label="True function")
    plt.scatter(X, y, edgecolor='b', s=20, label="Samples")
    plt.xlabel("x")
    plt.ylabel("y")
    plt.xlim((0, 1))
    plt.ylim((-1.5, 1.5))
    plt.legend(loc="best")
    plt.title("Degree {}\nMSE = {:.2e}(+/- {:.2e})".format(
        degree, -scores.mean(), scores.std()))
    if save_fig:
        filename = 'generated_fit_%d_%s.png' % (degree, "T" if show_true else "F")
        plt.savefig(filename, dpi=DPI, bbox_inches='tight')
    if show_fig: plt.show()
    
    return -scores.mean()

data = np.loadtxt('data/generated/sample_030.csv', delimiter=',')
X, y = data[:,0], data[:,1]   
    
degrees = [1,2,3,4,5,6,7,8,10,15]
for i, degree in enumerate(degrees):
    generate_fit(degree, save_fig=True)

