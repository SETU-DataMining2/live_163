def style_query_1(row):
    style = 'background-color: %s' % ('lightgreen' if row.Mark>=70 else 'white')
    return [style] * len(row)
df.style.apply(style_query_1, axis=1)