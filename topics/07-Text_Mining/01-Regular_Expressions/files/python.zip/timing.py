#!/usr/bin/env python

import re
r = re.compile(r"(a|aa)*b")


from timeit import default_timer as timer
for l in [10,20,40,80,160,240]:
    start = timer()
    r.match("a"*40 + "b")
    end = timer()
    print("%3d with time %.2e" % (l,end-start))

