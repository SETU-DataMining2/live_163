#!/usr/bin/env python

# minimal dats set 
dnaListYes = [
    "AGGCATGTCCTAACATGCCT",
    "AGGCATGTTTTAACATGCCT",
    "GGACATGTCCTAACATGCCC",
    "GGACATGTCCTAACTTGTGC",
    "GGAGGCATGTCCTAACATGCCTAA",
]
dnaListNo = [
    "AGGCATGTCCTAACATGCC",
    "CGGCATGTCCTAACATGCCT",
    "AGGCATGTCCTAAGATGCCT",
]

dnaList = dnaListYes + dnaListNo













# regular expression based search

import re
r = re.compile(r"[AG]{3,3}CATG[TC]{4,4}[AG]{2,2}C[AT]TG[CT][CG][TC]")

print ("RE searching ...")
for k, dna in enumerate(dnaList):
    
    m = r.search(dna)
    if m != None:
        print ("Sample %d (%s): match found at pos %s" % (k, dna, m.start()))
    else:
        print("Sample %d (%s): no match " % (k,dna))







# non-re (aka stupid) based searching 

print ("\nNon-RE searching ...")

for k, dna in enumerate(dnaList):
    
    for i in range(0,len(dna)-19):

        if ((dna[i] == "A" or dna[i] == "G") and
            (dna[i+1] == "A" or dna[i+1] == "G") and
            (dna[i+2] == "A" or dna[i+2] == "G") and
            (dna[i+3] == "C") and
            (dna[i+4] == "A") and
            (dna[i+5] == "T") and
            (dna[i+6] == "G") and
            (dna[i+7] == "C" or dna[i+7] == "T") and
            (dna[i+8] == "C" or dna[i+8] == "T") and
            (dna[i+9] == "C" or dna[i+9] == "T") and
            (dna[i+10] == "C" or dna[i+10] == "T") and
            (dna[i+11] == "A" or dna[i+11] == "G") and
            (dna[i+12] == "A" or dna[i+12] == "G") and
            (dna[i+13] == "C") and
            (dna[i+14] == "A" or dna[i+14] == "T") and
            (dna[i+15] == "T") and
            (dna[i+16] == "G") and
            (dna[i+17] == "C" or dna[i+17] == "T") and
            (dna[i+18] == "C" or dna[i+18] == "G") and
            (dna[i+19] == "C" or dna[i+19] == "T")):
            print ("Sample %d (%s): match found at pos %s" % (k, dna, i))
            break
    else:
        print("Sample %d (%s): no match " % (k,dna))
    