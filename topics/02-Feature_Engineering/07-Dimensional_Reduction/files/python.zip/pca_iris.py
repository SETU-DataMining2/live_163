#!/usr/bin/env python

# source: sklearn

from sklearn import datasets
from sklearn.decomposition import PCA
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis

iris = datasets.load_iris()

X, y = iris.data, iris.target

pca = PCA(n_components=4)
X_r = pca.fit(X).transform(X)

print('Explained variance ratio:\n%s'
    % str(pca.explained_variance_ratio_))
