#!/usr/bin/env python

"""
Script to generate matchs and non-matches of various regular expressions
"""

import re

dataYes = [ "beat a brat on a boat"]
dataNo = []

data = dataYes + dataNo

r = re.compile("b[a-z ]*t")
for s in data:
    m = r.search(s)
    if m is None:
        print ("No match found")
    else:
        print ("Match found at in %s:%s with value '%s' " % (m.start(),m.end(),m.group()))