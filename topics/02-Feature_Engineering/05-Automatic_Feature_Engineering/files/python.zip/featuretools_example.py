#!/usr/bin/env python
 
import pandas as pd
import numpy as np
import featuretools as ft

clients = pd.read_csv("data/clients.csv", 
    parse_dates = ["joined"])
loans = pd.read_csv("data/loans.csv", 
    parse_dates = ["loan_start", "loan_end"])
payments = pd.read_csv("data/payments.csv", 
    parse_dates = ["payment_date"])

import featuretools as ft

es = ft.EntitySet(id="clients")

# Create an entity from the client dataframe
# This dataframe already has an index and a time index
es = es.entity_from_dataframe(entity_id = "clients", 
    dataframe = clients, 
    index = "client_id", 
    time_index = "joined")
print(es)
# 
# Create an entity from the loans dataframe
# This dataframe already has an index and a time index
es = es.entity_from_dataframe(entity_id = "loans", 
    dataframe = loans, 
    variable_types = {"repaid": ft.variable_types.Categorical},
    index = "loan_id", 
    time_index = "loan_start")
print(es)
  
# Create an entity from the payments dataframe
# This does not yet have a unique index
es = es.entity_from_dataframe(entity_id = "payments", 
    dataframe = payments,
    variable_types = {"missed": ft.variable_types.Categorical},
    time_index = "payment_date",
    make_index = True,
    index = "payment_id")
print(es)


print(es["clients"])
print(es["loans"])
print(es["payments"])


# Relationship between clients and previous loans
r_client_previous = ft.Relationship(
    es["clients"]["client_id"], es["loans"]["client_id"])

# Add the relationship to the entity set
es = es.add_relationship(r_client_previous)

print(es)

# Relationship between previous loans and previous payments
r_payments = ft.Relationship(
    es["loans"]["loan_id"], es["payments"]["loan_id"])

# Add the relationship to the entity set
es = es.add_relationship(r_payments)

print(es)

# Create new features using specified primitives
features, feature_names = ft.dfs(
    entityset = es, 
    target_entity = "clients", 
    agg_primitives = ["mean", "max", "percent_true", "last"],
    trans_primitives = ["years", "month", "subtract", "divide"])

print("Numbwer of features", len(features.columns))

pd.DataFrame(features["MONTH(joined)"].head())
pd.DataFrame(features['MEAN(payments.payment_amount)'].head())
features.head()
